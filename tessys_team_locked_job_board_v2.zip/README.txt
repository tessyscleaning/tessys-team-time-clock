Updated version: delete selected job, clear filtered jobs, clear all jobs. Main file: team_locked_job_board.py
